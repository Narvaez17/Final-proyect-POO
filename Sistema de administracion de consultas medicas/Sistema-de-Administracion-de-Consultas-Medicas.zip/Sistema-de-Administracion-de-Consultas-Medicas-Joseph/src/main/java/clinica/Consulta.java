package clinica;

public class Consulta {
    
    // Constructor básico
    public Consulta() {
    }
    
}

