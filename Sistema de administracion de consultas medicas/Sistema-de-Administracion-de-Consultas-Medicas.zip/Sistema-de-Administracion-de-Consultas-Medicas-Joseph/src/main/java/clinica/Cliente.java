package clinica;

public class Cliente {
    
    // Constructor básico
    public Cliente() {
    }
    
}

