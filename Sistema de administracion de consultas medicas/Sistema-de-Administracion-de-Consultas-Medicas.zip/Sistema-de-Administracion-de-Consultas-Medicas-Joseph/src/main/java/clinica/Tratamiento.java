package clinica;

public class Tratamiento {
    
    // Constructor básico
    public Tratamiento() {
    }
    
}

